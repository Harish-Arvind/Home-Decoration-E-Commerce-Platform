module.exports = {
    'secret': 'your_secret'
   };