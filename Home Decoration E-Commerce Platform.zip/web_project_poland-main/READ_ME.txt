administrator:
user: testadmin
password : admin123

-----WARNING-----
Before running the project you must change the db.js file to put your username and password of your own local database

-----RUNNING-----
To run the project you must install node modules in home_decoration_page folder and in WebServer folder
To see the webpage run execute: npm run dev  (you must be in the home_decoration_page folder)
To run the database run : npm start  (you must be in the WebServer folder)
